## Questões da Analise Léxica
- Problemas
- Lookahead

## Exemplo de Resultado Final
```c++
if (i == j) 
	z = 0; 
else 
	z = 1;
```

A entrada consiste apensa em uma de cadeia de caracteres.
```c++
\tif (i == j)\n\t\tz = 0;\n\telse\n\t\tz = 1;
```

Então o código seria uma grande entrada de texto que vai ser scanneado pelo analisador léxico.

## **Objetivo**
Vamos particionar a sequência de caracteres da entrada em subcadeis
- Cada subcadeia deve representar um *==token==*

## **Token**
==O token vai estar associado a uma **categoria sintática**==
- Em uma linguagem LN (linguagem natural), ela representaria os substantivos, verbos, objetivos.
- Em programação, vão ser associados aos identificadores, palavras-chave, constantes inteiras...

*Exemplos:*
- **Identificador**: Cadeia de caracteres e dígitos iniciadas por caracteres
- **Palavra-chave**: `if,else,begin,...`
- **Constante inteira**: cadeia não vazia de dígitos
- **Whitespace**: sequência não vazia de espaços, `\t , \n`
- **Etc...**

### Função do token
Permitir classificar as subcadeias de uma programa de acordo com o seu papel e função.

A ==saída da análise léxica== é uma sequencia de tokens, que é utilizada como ==entrada da [analise sintática](obsidian://open?vault=Obsidian%20Vault&file=Compiladores%2FAnalise%20Sintatica)==

O analisador sintático é totalmente dependente da diferenciação e distinção dos *tokens*

----
# Projeto do analisador léxico
## Passo 1
Definir um conjunto **finito** de *tokens*
- *Tokens* devem descrever todos os itens/elementos de interesse
- A escolha das ==*tokens* depende== da ==linguagem== e do projeto do ==parser== 

Para a entrada:
```c
\tif (i == j)\n\t\tz = 0;\n\telse\n\t\tz = 1;
```
Um possível bom conjunto de *tokens* seria:
>Integer, Keyword, Relation, Identifier, Whitespace, (, ), =, ;

**Obs:** ( ) = ; representam ***TOKENS***, não caracteres!

## Passo 2
==Descrever== quais são as ==cadeias de caracteres associadas== a uma dada *==token==*

____
# Implementação de uma Analisador Léxico
Uma implementação de analisador léxico deve realizar duas atividades:
1. Reconhecer subcadeias de caracteres que correspondam as *tokens*
2. Retornar o valor ou **==Lexema==** da *token*
	 -> **==Lexema==** corresponde a ==subcadeia de caracteres que foi identificada==

**Exemplo de implementação:**
Entrada:
```c
\tif (i == j)\n\t\tz = 0;\n\telse\n\t\tz = 1;
```

O analisador léxico deve geralmente **descartar tokens de pouco ou nenhum interesse** (que não contribuem para o *parsing*)
	**ex:** Whitespace, Comment...

## *Lookahead*
Para o exemplo:
```c
\tif (i == j)\n\t\tz = 0;\n\telse\n\t\tz = 1;
```

Vai ser necessário o uso de "***lookahead***" em várias situações. 
**exemplo:**
- `i x n`
- `= x ==`

## ==Basicamente==
O **objetivo** de análise léxica é:
- **Particionar a entrada em lexemas**
- **Identificar a *token* de cada lexema**
-------
# Linguagem Regular
### Linguagem - Definição
Seja **Σ** um conjunto de caracteres (ou símbolos) - também denominado de **Alfabeto**.
Uma **linguagem** sobre Σ é um **subconjunto** do conjunto de todas cadeias de caracteres que podem ser produzidas a partir de Σ 

### Linguagem Regular - Definição
==Linguagem regular== é aquela que pode ser ==produzida utilizada== as operações de ==**concatenação,** **união**, **fecho de Kleene**== sobre os ==elementos== de um ==afalbeto==.

Linguagem regular representa o formalismo **mais popular** para **especificação de *lexemas*/*tokens*** pois possui teoria simples, é fácil de compreender e pode ser e pode ser implementada **eficientemente**.

Uma **expressão regular** representa uma linguagem regular

----
# Expressão Regular
## Definição recursiva de Expressão Regular
1. **Base:** os conjuntos regulares ∅, {λ} e {a}, ∀a ∈ Σ são representados pelas expressões regulares ∅, λ e a, ∀a ∈ Σ;
2. **Passo Recursivo:** Sejam **r** e **s** duas expressões regulares que denotam os conjuntos regulares **R** e **S**, respectivamente, então:
	- **r** ∪ **s** é um *regex* que denota **R** ∪ **S**
	- **rs** é um regex que denotar **RS**, e
3. **Fechamento:** **R** é uma expressão regular sobre Σ se e somente se **puder** ser obtida a partir de um número finito de aplicações do passo recursivo sobre os elementos da base.

## Conjunto Regular × Expressão Regular
![[Sem título-2023-03-09-2300.png]]
A ordem de **prioridade** das **operações** é:
	***fechamento** -> **concatenação** -> **união*** 

Pode-se usar **|** ou **+** em lugar de **∪**

#### **Exemplos:**
- **Identificador:** cadeia de caracteres e dígitos iniciadas por um caractere
	- **letra** = *A | B | . . . | Z | a | b | . . . | z*
	- **digito** = 0 | 1 | . . . | 9
	- **id** = *letra (letra | digito) ∗*
	
- **Constante Inteira:**  cadeia não vazia de dígitos
	- **digito** = *0 | 1 | . . . | 9*
	- **num** = *digito digito*∗
	
- **Whitespace:** Uma sequência não vazia de espaços, `\t e \n`
	- **ws** = `’ ’ | ’\n’ | ’\t’`
	- **ws_seq** = *ws**

- **Números sem sinal** (inteiros ou ponto flutuante):
	- **digito** = *0 | 1 | . . . | 9* 
	- **digitos** = *digito digito∗* 
	- **op_frac** = *’.’ digitos | λ* 
	- **op_exp** = *(E (+ | − | λ) digitos) | λ* 
	- **unsigned_num** = *digitos opt_frac opt_exp*

- **Palavra-chave:** `if, else, ...`
	- **keyword** = *’i’ ’f’ | ’e’ ’l’ ’s’ ’e’ | . . .*
	- **keyword** = *’if’ | ’else’ | . . .*

- **Identificador:** cadeia de caracteres e dígitos iniciadas por um caractere
	- **Letra** = *[A − Za − z]*
	- **Digito** = *[0 − 9]*
	- **ID** = *letra (letra | digito) ∗*

- **Números sem sinal** (inteiros ou ponto flutuante):
	- **Dígito** = *[0 - 9]*
	- **Dígitos** = *digito+*
	- **unsigned_num** = *digitos (’.’ digitos)? (E [+−]? digitos)?*
	
# Notação Lexica
- A forma de Backus Naur (BNF) vai definir a sintaxe da linguagem
- O código fonte é escrito nesta linguagem
- O compilador vai professar o código fonte segundo as regras da BNF.
	- Nós ==não== queremos fazer =="caracter a caracter"== individualmente!
- O primeiro passo é identificar os elementos léxicos (*tokens*) do código fonte.
	- Identificar grupos de caracteres que formam *tokens*

## O analisador léxico
- Também conhecido como *scanner*
- Papéis:
	- Transformar um fluxo de *caracteres* em *tokens*
	- Expor os *tokens* para o resto do compilador

**Entrada**:
```c
if (x==10)...
```
**Saída:**
```output
"if" "(" "" "==" "" ")" …
```

## Criando um scanner
- Devemos criar um scanner =="sob medida"== normalmente baseado em uma máquina de estado finito (FSM).
- Utilizar um utilitário para processar a especificação da linguagem e gerar automaticamente um *scanner*.

## Processamento com Flex
- *Lex* foi criada para ser um forma de gerar o analisador léxico em C
- A criação dos padrões combinando *meta-caracteres* é o núcleo da criação de um programa *Lex*

**Programa em lex:**
*Caráter, palavra, contador de linha*
```c
%{
 int lineCount, wordCount, charCount;
%}

%%
\n lineCount++;
[^ \t\n]+ { wordCount++; charCount+=yyleng; }
. charCount++;
%%

int yywrap ()
{ return 1; }
int main () {
 yylex();
 printf ("Input contains \n");
 printf ("%d lines\n%d words\n%d chars\n", lineCount, wordCount, charCount);
 return 0;
}
```

### Pattern matching
- A ==entrada== faz o =="match" caracter a caracter==
- Então uma ação pode ser executada
	-  Se dois padrões dão "*match*":
		- O padrão mais longo será usado:
		- Se forem de mesmo tamanho, o primeiro será usado.
- Se não tiver "*match*", copia a entrada para a saída

### Definições
- Padrões podem ser um nome na seção "*definitions*" e este nome pode ser usado em uma regra na forma {…}.

**EX:**
```c
LETTER [a-zA-Z]

%{ int wc; %}

%%
{LETTER}+ wc++;
.|\n ;
%%

int yywrap() { return 1; }

int main() {
    yylex();
    printf ("%d words found.\n", wc);
    return 0;
}
```
--------------

## **Próximo Tópico**:
**Autômatos** -> [Autômatos](Automatos.md)

----
## PDF's
![[anexos/03-analise-lexica.pdf]]
![[anexos/03.1-notacao_lex.pdf]]
![[anexos/04-automatos.pdf]]
