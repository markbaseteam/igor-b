A matéria de compiladores vai ser divida em 3 páginas:
1. [Analise Lexica](obsidian://open?vault=Obsidian%20Vault&file=Compiladores%2FAnalise%20Lexica)
2. Analise Sementica
3. Analise Sintatica


