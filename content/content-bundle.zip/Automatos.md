# Sumário
**1.  Especificação Léxica**:
   - Uso de ERs
   - Ambiguidades
   - Tratamento de Erros

**2. Autômato Finito:**
   - Autômato Finito Determinístico
   - Autômato Finito Não Determinístico
   - Comportamento de AFN
   - Transição Vazia

**3. Implementação:**
   - ER -> AFN
   - AFN -> AFD
   - Outros detalhes de implementação
   
---------------
# Especificação Léxica

## Uso de Expressões Regulares
Ers fornecem um formalismo para especificação léxica

1. Escrever uma ER para os lexemas de cada *token*
	Keyword = `’if’ | ’else’ | . . .`
	identifier = letra (letra | digito) ∗
	number = digito+
	. . .

2. Construir uma ER *R* que corresponda a todos os lexemas de todas as tokens
	*R* = keyword | identifier | number | . . .

3. Seja a entrada a sequência de caracteres $x_1...x_n$ , verificar para i, em que $1\leq i   \leq n$ 
se $x_1...x_i \in L(R)$ 

4. Em caso de sucesso, então, como *R* é a união de *ERs* para cada *token*, é possível determinar que $x_1...x_i \in L(R_j)$ para alguma *token* *j*

5. Remover $x_1...x_i$ da entrada, caso a entrada não se esgotar, voltar ao passo **3**

## Ambiguidades
O algoritmo anterior apresenta ambiguidades

Quantos caracteres de entrada devem ser usados/"consumidos"?

O que fazer se, para valores distintos de *i* e $k, x_1...x_i \in L(R)$?

**Regra**: Optar pela sequência de caracteres mais longa em L(R)
-  "Maximal Munch"

Como selecionar entre várias *tokens* possíveis?

O que fazer se, para valores distintos, de *j* e *k*, $x_1...x_i \in L(R_j)$ e também $x_1...x_i \in L(R_k)$?

**Regra:** Usar a regra que vier listada antes (por exemplo *j*, se *j < k*)

-----------
## PDF's
![[anexos/04-automatos.pdf]]
